package com.alan.clients.ui.menu;

import com.alan.clients.util.Accessor;
import net.minecraft.client.gui.GuiScreen;

public abstract class Menu extends GuiScreen implements Accessor, MenuColors {

}
