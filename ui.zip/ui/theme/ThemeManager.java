package com.alan.clients.ui.theme;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public final class ThemeManager {
    private Themes theme = Themes.BLEND;
}
