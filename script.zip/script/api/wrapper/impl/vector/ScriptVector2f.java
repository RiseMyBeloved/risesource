package com.alan.clients.script.api.wrapper.impl.vector;

public class ScriptVector2f {
    private float x, y;

    public ScriptVector2f(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public void setX(float x) {
        this.x = x;
    }

    public void setY(float y) {
        this.y = y;
    }
}
