package com.alan.clients.script.api;

public class WebAPI {
    public void download(String url, String path) {
        System.out.println("Unfinished");
    }
}
