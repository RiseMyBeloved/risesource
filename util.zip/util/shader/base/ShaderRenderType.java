package com.alan.clients.util.shader.base;

public enum ShaderRenderType {
    CAMERA, OVERLAY
}
