package com.alan.clients.util.file;
public enum FileType {
    ACCOUNT, CONFIG, INSULT, SCRIPT
}
