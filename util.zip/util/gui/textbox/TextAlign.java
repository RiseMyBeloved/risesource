package com.alan.clients.util.gui.textbox;

public enum TextAlign {
    LEFT,
    CENTER
}
