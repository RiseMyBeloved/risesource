package com.alan.clients.util;

public interface Factory<T> {
    T build();
}