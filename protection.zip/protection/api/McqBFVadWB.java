package com.alan.clients.protection.api;

public enum McqBFVadWB {
    INITIALIZE,
    REPETITIVE,
    POST_INITIALIZE,
    JOIN
}
