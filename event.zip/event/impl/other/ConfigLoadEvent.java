package com.alan.clients.event.impl.other;

import com.alan.clients.event.Event;

public final class ConfigLoadEvent implements Event {

}