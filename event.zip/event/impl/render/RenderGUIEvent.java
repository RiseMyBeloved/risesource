package com.alan.clients.event.impl.render;

import com.alan.clients.event.Event;

public final class RenderGUIEvent implements Event {

}
