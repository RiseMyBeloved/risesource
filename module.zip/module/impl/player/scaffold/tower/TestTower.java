package com.alan.clients.module.impl.player.scaffold.tower;

import com.alan.clients.event.Listener;
import com.alan.clients.event.annotations.EventLink;
import com.alan.clients.event.impl.motion.PreMotionEvent;
import com.alan.clients.event.impl.motion.StrafeEvent;
import com.alan.clients.module.impl.player.Scaffold;
import com.alan.clients.util.player.MoveUtil;
import com.alan.clients.util.player.PlayerUtil;
import com.alan.clients.value.Mode;
import net.minecraft.potion.Potion;

public class TestTower  extends Mode<Scaffold> {
    public TestTower(String name, Scaffold parent) {
        super(name, parent);
    }

    @EventLink
    public final Listener<PreMotionEvent> onPreMotionEvent = event -> {
        if (mc.gameSettings.keyBindJump.isKeyDown() && PlayerUtil.blockNear(1)) {
            mc.thePlayer.motionY = 0.8F;
        }

    };

    @EventLink
    public final Listener<StrafeEvent> onStrafe = event -> {


        if (mc.thePlayer.motionY<.77) {
          //  event.setSpeed(.4);
            if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
          //      MoveUtil.strafe(((.01 * (1 + (mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier()))) + 0.1));
            }
        }
   };



    }

