package com.alan.clients.module.impl.render;

import com.alan.clients.module.Module;
import com.alan.clients.module.api.Category;
import com.alan.clients.module.api.ModuleInfo;

@ModuleInfo(aliases = {"module.render.unlimitedchat.name"}, category = Category.RENDER, description = "module.render.unlimitedchat.description")
public final class UnlimitedChat extends Module {
    // Done in GuiNewChat
}
