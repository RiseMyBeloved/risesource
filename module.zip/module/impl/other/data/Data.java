package com.alan.clients.module.impl.other.data;

public class Data {
    public static States<Entity> pStates = new States<>(10);
    public static States<Entity> eStates = new States<>(10);
}
