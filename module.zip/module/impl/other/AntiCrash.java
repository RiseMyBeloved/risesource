package com.alan.clients.module.impl.other;

import com.alan.clients.module.Module;
import com.alan.clients.module.api.Category;
import com.alan.clients.module.api.ModuleInfo;

@ModuleInfo(aliases = {"module.other.anticrash.name", "Security Features", "Anti Exploit"}, description = "module.other.anticrash.description", category = Category.PLAYER)
public final class AntiCrash extends Module {
}
