package com.alan.clients.module.impl.other;

import com.alan.clients.module.Module;
import com.alan.clients.module.api.Category;
import com.alan.clients.module.api.ModuleInfo;

@ModuleInfo(aliases = {"module.other.nopitchlimit.name"}, description = "module.other.nopitchlimit.description", category = Category.PLAYER)
public class NoPitchLimit extends Module {
}
