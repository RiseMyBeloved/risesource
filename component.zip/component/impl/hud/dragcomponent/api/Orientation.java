package com.alan.clients.component.impl.hud.dragcomponent.api;

public enum Orientation {
    VERTICAL,
    HORIZONTAL
}
