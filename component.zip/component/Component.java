package com.alan.clients.component;

import com.alan.clients.util.Accessor;

public abstract class Component implements Accessor {
    public void onInit() {

    }
}
